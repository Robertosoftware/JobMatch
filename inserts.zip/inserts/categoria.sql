INSERT INTO `mydb`.`categoria` (`idcategoria`, `nombre`, `descripcion`) VALUES ('1', 'Ingenieria', 'Ingenierias');
