INSERT INTO `mydb`.`competencia` (`idcompetencia`, `nombre`, `subcategoria_idsubcategoria`) VALUES ('1', 'Programaci�n orientada a objetos', '1');
INSERT INTO `mydb`.`competencia` (`idcompetencia`, `nombre`, `subcategoria_idsubcategoria`) VALUES ('2', 'Bases de datos', '1');
INSERT INTO `mydb`.`competencia` (`idcompetencia`, `nombre`, `subcategoria_idsubcategoria`) VALUES ('3', 'Programacion para Web', '1');
INSERT INTO `mydb`.`competencia` (`idcompetencia`, `nombre`, `subcategoria_idsubcategoria`) VALUES ('4', 'Sistemas operativos', '1');
INSERT INTO `mydb`.`competencia` (`idcompetencia`, `nombre`, `subcategoria_idsubcategoria`) VALUES ('5', 'Programacion', '1');
