ALTER TABLE `mydb`.`subcategoria` 
CHANGE COLUMN `nombre` `nombre` VARCHAR(100) NOT NULL ;
INSERT INTO `mydb`.`subcategoria` (`idsubcategoria`, `nombre`, `categoria_idcategoria`) VALUES ('1', 'Ingenieria en sistemas y tecnologias de informacion', '1');
