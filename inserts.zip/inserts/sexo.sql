ALTER TABLE `mydb`.`sexo` 
CHANGE COLUMN `nombre` `nombre` VARCHAR(25) NOT NULL ;

INSERT INTO `mydb`.`sexo` (`idsexo`, `nombre`) VALUES ('1', 'Femenino');
INSERT INTO `mydb`.`sexo` (`idsexo`, `nombre`) VALUES ('2', 'Masculino');
INSERT INTO `mydb`.`sexo` (`idsexo`, `nombre`) VALUES ('3', 'Prefiero no especificar');
