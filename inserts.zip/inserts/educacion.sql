INSERT INTO `mydb`.`educacion` (`ideducacion`, `nombre`) VALUES ('1', 'Doctorado');
INSERT INTO `mydb`.`educacion` (`ideducacion`, `nombre`) VALUES ('2', 'Maestria o especialidad');
INSERT INTO `mydb`.`educacion` (`ideducacion`, `nombre`) VALUES ('3', 'Licenciatura');
INSERT INTO `mydb`.`educacion` (`ideducacion`, `nombre`) VALUES ('4', 'Bachillerato');
INSERT INTO `mydb`.`educacion` (`ideducacion`, `nombre`) VALUES ('5', 'Secundaria');
