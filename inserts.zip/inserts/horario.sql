ALTER TABLE `mydb`.`horario` 
CHANGE COLUMN `tipo` `tipo` VARCHAR(60) NOT NULL ;



INSERT INTO `mydb`.`horario` (`id_horario`, `tipo`) VALUES ('1', 'Medio tiempo Matutino');
INSERT INTO `mydb`.`horario` (`id_horario`, `tipo`) VALUES ('2', 'Medio tiempo vespertino');
INSERT INTO `mydb`.`horario` (`id_horario`, `tipo`) VALUES ('3', 'Medio tiempo');
INSERT INTO `mydb`.`horario` (`id_horario`, `tipo`) VALUES ('4', 'Tiempo completo');
INSERT INTO `mydb`.`horario` (`id_horario`, `tipo`) VALUES ('5', 'Cualquier horario');
