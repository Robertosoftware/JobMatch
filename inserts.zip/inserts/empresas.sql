ALTER TABLE `mydb`.`empresa` 
CHANGE COLUMN `correo` `correo` VARCHAR(55) NULL ,
CHANGE COLUMN `telefono` `telefono` VARCHAR(15) NULL ;

ALTER TABLE `mydb`.`empresa` 
CHANGE COLUMN `telefono` `telefono` VARCHAR(20) NULL DEFAULT NULL ;


INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `telefono`) VALUES ('1', 'Grupo salinas', '5551911474');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `descripcion`, `telefono`) VALUES ('2', 'Manpower', 'Insurgentes Centro 36, colonia Tabacalera', '5528995303');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `descripcion`, `telefono`) VALUES ('3', 'Posadas', 'Prolongaci�n Paseo de la Reforma 1015 Piso 9 Torre A Col Santa Fe Del. �lvaro Obreg�n CP 01210, M�xico DF', '+52 (55) 5326 6700');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `correo`, `telefono`) VALUES ('4', 'Profuturo', 'servicioaclientes@profuturo.com.mx', '58 09 65 55');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `descripcion`, `correo`) VALUES ('5', 'tkm', 'Av. Amores 321, Col. Del Valle, Del. Benito Ju�rez, C.P. 03100, CDMX', 'soluciones@tkm.com.mx');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `telefono`) VALUES ('6', 'Santander', '51694300');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `telefono`) VALUES ('7', 'Citibanamex', '2262 6391');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `telefono`) VALUES ('8', 'Sanpablo', '(55) 5354 9000');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `telefono`) VALUES ('9', 'Grupo prodensa', '52 81 1161 90 00');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `telefono`) VALUES ('10', 'Inbursa', ' 5447 8000 ');
INSERT INTO `mydb`.`empresa` (`idempresa`, `nombre`, `descripcion`, `correo`, `telefono`) VALUES ('11', 'Nelson Vargas', 'Camino a Santa Teresa 187-C, piso 4, Col. Parque del Pedregal, M�xico D.F, C�digo postal: 14010', 'contacto@anv.com.mx', '	(55) 5424 8455');
