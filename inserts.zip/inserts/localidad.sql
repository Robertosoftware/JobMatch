INSERT INTO `mydb`.`localidad` (`idlocalidad`, `nombrel`) VALUES ('1', 'CDMX');
INSERT INTO `mydb`.`localidad` (`idlocalidad`, `nombrel`) VALUES ('2', 'Edo. Mex');
