INSERT INTO `mydb`.`ingles` (`idingles`, `nivel`) VALUES ('1', 'Nada');
INSERT INTO `mydb`.`ingles` (`idingles`, `nivel`) VALUES ('2', 'Basico');
INSERT INTO `mydb`.`ingles` (`idingles`, `nivel`) VALUES ('3', 'Intermedio');
INSERT INTO `mydb`.`ingles` (`idingles`, `nivel`) VALUES ('4', 'Avanzado');
